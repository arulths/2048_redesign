var searchData=
[
  ['gameview',['GameView',['../classcom_1_1group2_1_1_view_1_1_game_view.html#ab4e84674b218c263cc7468a9c96554c3',1,'com::group2::View::GameView']]],
  ['getbackground',['getBackground',['../classcom_1_1group2_1_1_model_1_1_tile.html#aa7b7418a3113005b9379c51a7f9bceba',1,'com::group2::Model::Tile']]],
  ['getforeground',['getForeground',['../classcom_1_1group2_1_1_model_1_1_tile.html#ab801bce0bbf470dbc3812dd13a8041bf',1,'com::group2::Model::Tile']]],
  ['getvalue',['getValue',['../classcom_1_1group2_1_1_model_1_1_tile.html#a74fcea6424fb44e6705a0ed295eb1a5f',1,'com::group2::Model::Tile']]]
];
