var searchData=
[
  ['gameview',['GameView',['../classcom_1_1group2_1_1_view_1_1_game_view.html',1,'com::group2::View']]]
];
