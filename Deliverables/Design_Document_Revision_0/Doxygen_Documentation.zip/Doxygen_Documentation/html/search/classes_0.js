var searchData=
[
  ['board',['Board',['../classcom_1_1group2_1_1_model_1_1_board.html',1,'com::group2::Model']]]
];
