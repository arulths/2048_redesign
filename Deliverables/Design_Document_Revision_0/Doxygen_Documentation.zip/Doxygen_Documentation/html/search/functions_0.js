var searchData=
[
  ['board',['Board',['../classcom_1_1group2_1_1_model_1_1_board.html#a1f3c480cb3b8c630620403b20c58e997',1,'com::group2::Model::Board']]]
];
