var searchData=
[
  ['screenheight',['ScreenHeight',['../classcom_1_1group2_1_1_controller_1_1_main.html#acfaa5b51e1e6f7c200e88302ee2a8b8c',1,'com::group2::Controller::Main']]]
];
