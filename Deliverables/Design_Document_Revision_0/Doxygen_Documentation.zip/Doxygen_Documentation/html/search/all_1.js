var searchData=
[
  ['canmove',['canMove',['../classcom_1_1group2_1_1_model_1_1_board.html#a1f4a4fb2b0685d27388a4bbdc7e381b8',1,'com::group2::Model::Board']]]
];
