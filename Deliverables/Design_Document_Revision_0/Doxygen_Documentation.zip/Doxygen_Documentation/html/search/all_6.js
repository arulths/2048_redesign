var searchData=
[
  ['left',['left',['../classcom_1_1group2_1_1_model_1_1_board.html#aa3e030a2a797348b606635a0ad61afda',1,'com::group2::Model::Board']]]
];
