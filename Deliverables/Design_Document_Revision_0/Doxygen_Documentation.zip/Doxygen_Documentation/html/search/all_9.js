var searchData=
[
  ['resetgame',['resetGame',['../classcom_1_1group2_1_1_model_1_1_board.html#ae214a2274071031fec2dccaacf877cab',1,'com::group2::Model::Board']]],
  ['right',['right',['../classcom_1_1group2_1_1_model_1_1_board.html#a697534c5f90749b93d44792272f9b722',1,'com::group2::Model::Board']]]
];
