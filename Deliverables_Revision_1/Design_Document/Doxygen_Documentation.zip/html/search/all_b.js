var searchData=
[
  ['up',['up',['../classcom_1_1group2_1_1_model_1_1_board.html#a7e69b0747184d6406440b735262ccb07',1,'com::group2::Model::Board']]]
];
