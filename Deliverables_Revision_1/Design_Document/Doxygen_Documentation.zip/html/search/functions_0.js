var searchData=
[
  ['board',['Board',['../classcom_1_1group2_1_1_model_1_1_board.html#a9f8859cb157c981320573644b0b8da23',1,'com::group2::Model::Board']]]
];
