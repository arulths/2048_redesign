var searchData=
[
  ['state',['State',['../enumcom_1_1group2_1_1_model_1_1_board_1_1_state.html',1,'com::group2::Model::Board']]]
];
