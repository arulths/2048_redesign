var searchData=
[
  ['screenheight',['screenHeight',['../classcom_1_1group2_1_1_view_1_1_game_window.html#ae5cdb6d1ecc6e2fa12a4e8c30ff30cc1',1,'com::group2::View::GameWindow']]],
  ['state',['State',['../enumcom_1_1group2_1_1_model_1_1_board_1_1_state.html',1,'com::group2::Model::Board']]]
];
