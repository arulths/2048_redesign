var searchData=
[
  ['down',['down',['../classcom_1_1group2_1_1_model_1_1_board.html#a6acc68b2111da4cde71eb4bd42039c77',1,'com::group2::Model::Board']]]
];
